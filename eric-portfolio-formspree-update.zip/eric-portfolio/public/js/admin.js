(function () {
  'use strict';
  var csrf = '', timer = null;
  var loginView = $('#loginView'), dashView = $('#dashView'), dashMsg = $('#dashMsg');
  function call(url, method, body) {
    return api(url, { method: method, body: body, headers: { 'X-CSRF-Token': csrf } }).catch(function (e) {
      if (e.status === 401) showLogin();
      throw e;
    });
  }
  function showLogin() { clearInterval(timer); dashView.classList.add('hidden'); loginView.classList.remove('hidden'); }
  function showDash() { loginView.classList.add('hidden'); dashView.classList.remove('hidden'); buildSlots(); load(); clearInterval(timer); timer = setInterval(load, 20000); }
  function cell(text, cls) { return h('td', { class: cls || '', text: text }); }
  function btn(label, cls, fn) { var b = h('button', { class: 'btn sm ' + (cls || ''), type: 'button', text: label }); b.addEventListener('click', fn); return b; }
  function fail(e) { notice(dashMsg, 'err', e.message); }


  var SLOTS = [
    { id: 'profile', label: 'Profile / bio photo', help: 'Shows at the top of the Home page and on your About page.' },
    { id: 'home-banner', label: 'Home page banner', help: 'A wide picture under the Home page headline (for example you at work).' },
    { id: 'about-extra', label: 'Second About photo', help: 'A second picture on the About page, under your profile photo.' }
  ];
  // Shrink phone photos before upload so pages load fast and data is saved.
  function shrink(file, maxDim) {
    function draw(src, w, h0) {
      var max = maxDim || 1600, r = Math.min(1, max / Math.max(w, h0));
      var c = document.createElement('canvas'); c.width = Math.round(w * r); c.height = Math.round(h0 * r);
      var ctx = c.getContext('2d'); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, c.width, c.height); // white behind transparent PNGs
      ctx.drawImage(src, 0, 0, c.width, c.height);
      return new Promise(function (resolve, reject) {
        c.toBlob(function (bl) { bl ? resolve(bl) : reject(new Error('Could not read that picture.')); }, 'image/jpeg', 0.85);
      });
    }
    if (window.createImageBitmap) {
      return createImageBitmap(file).then(function (bmp) { return draw(bmp, bmp.width, bmp.height); })
        .catch(function () { throw new Error('Could not read that picture. Try a JPG or PNG.'); });
    }
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () {
        var img = new Image();
        img.onload = function () { draw(img, img.width, img.height).then(resolve, reject); };
        img.onerror = function () { reject(new Error('Could not read that picture.')); };
        img.src = fr.result;
      };
      fr.onerror = function () { reject(new Error('Could not read that picture.')); };
      fr.readAsDataURL(file);
    });
  }
  function uploadBlob(blob) {
    return fetch('/api/admin/upload', { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'image/jpeg', 'X-CSRF-Token': csrf }, body: blob })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.error || 'Upload failed.'); return d; }); });
  }
  function buildSlots() {
    var wrap = $('#picSlots'); wrap.textContent = '';
    api('/api/images').then(function (imgs) {
      SLOTS.forEach(function (sl) {
        var cur = imgs[sl.id], file = h('input', { type: 'file', accept: 'image/*' }), link = h('input', { type: 'url', placeholder: 'https://... (optional link instead)', maxlength: '600' });
        var alt = h('input', { maxlength: '150', placeholder: 'Short description of the picture', value: cur && cur.alt ? cur.alt : '' });
        var save = h('button', { class: 'btn sm', type: 'button', text: 'Save picture' });
        var rm = h('button', { class: 'btn sm danger', type: 'button', text: 'Remove' });
        save.addEventListener('click', async function () {
          save.disabled = true;
          try {
            var src = link.value.trim();
            if (file.files[0]) src = (await uploadBlob(await shrink(file.files[0]))).src;
            if (!src) throw new Error('Choose a picture or paste a link first.');
            await call('/api/admin/images/' + sl.id, 'PUT', { src: src, alt: alt.value });
            notice(dashMsg, 'ok', 'Picture saved. Refresh your site to see it.'); buildSlots();
          } catch (e) { fail(e); }
          save.disabled = false;
        });
        rm.addEventListener('click', function () { call('/api/admin/images/' + sl.id, 'DELETE').then(buildSlots).catch(fail); });
        var kids = [h('strong', { text: sl.label }), h('p', { class: 'muted', text: sl.help })];
        if (cur && cur.src) kids.push(h('img', { src: cur.src, alt: '' }));
        kids.push(h('div', { class: 'stack' }, [h('div', {}, [h('label', { text: 'Upload from phone or computer' }), file]), h('div', {}, [h('label', { text: 'Or picture link' }), link]),
          h('div', {}, [h('label', { text: 'Description' }), alt]), h('div', { class: 'row-actions' }, cur && cur.src ? [save, rm] : [save])]));
        wrap.appendChild(h('div', { class: 'pic-row' }, kids));
      });
    }).catch(function () {});
  }

  function who(b) {
    var kids = [h('strong', { text: b.name }), h('br'), (/^[\w.+\-]+@[\w.\-]+$/.test(b.email) ? h('a', { href: 'mailto:' + b.email, text: b.email }) : h('span', { text: b.email }))];
    if (b.phone) {
      kids.push(h('br'), h('span', { text: b.phone + '  ' }));
      var d = b.phone.replace(/\D/g, '');
      if (d.length === 11 && d.charAt(0) === '0') d = '234' + d.slice(1); // Nigerian number written as 0815...
      if (d.length >= 8 && d.length <= 15) kids.push(h('a', { href: 'https://wa.me/' + d, target: '_blank', rel: 'noopener noreferrer', text: 'Open WhatsApp' }));
    }
    return kids;
  }
  var mailWarned = false, storeWarned = false, settingsFilled = false;
  async function load() {
    try {
      var d = await call('/api/admin/data', 'GET');
      if (d.storageWarning && !storeWarned) { storeWarned = true; notice(dashMsg, 'err', 'WARNING: your bookings and lessons are saved in temporary files and will be erased when the site restarts. Connect Supabase (see the README) or attach a Render disk.'); }
      if (d.mail && !d.mail.enabled && !mailWarned && !storeWarned) { mailWarned = true; notice(dashMsg, 'err', 'Booking alerts are OFF. Add FORMSPREE_URL in your hosting settings to get an email for every booking.'); }
      $('#sBook').textContent = d.bookings.length;
      $('#sNew').textContent = d.bookings.filter(function (b) { return b.status === 'new'; }).length;
      $('#sSub').textContent = d.subscribers.length; $('#sPost').textContent = d.posts.length;

      var bb = $('#bookBody'); bb.textContent = '';
      d.bookings.slice().reverse().forEach(function (b) {
        var sel = h('select', {}, ['new', 'confirmed', 'done'].map(function (s) { var o = h('option', { value: s, text: s }); if (s === b.status) o.selected = true; return o; }));
        sel.addEventListener('change', function () { call('/api/admin/bookings/' + b.id, 'PATCH', { status: sel.value }).then(load).catch(fail); });
        bb.appendChild(h('tr', {}, [
          cell(fmtDate(b.createdAt) + (b.preferredDate ? ' (wants ' + b.preferredDate + ')' : '')),
          h('td', {}, who(b)),
          cell(b.service), cell(b.details, 'wrap'), h('td', {}, [sel]),
          h('td', {}, [btn('Delete', 'danger', function () { if (confirm('Delete this booking?')) call('/api/admin/bookings/' + b.id, 'DELETE').then(load).catch(fail); })])
        ]));
      });
      if (!d.bookings.length) bb.appendChild(h('tr', {}, [h('td', { colspan: 6, text: 'No bookings yet.' })]));

      var pb = $('#postBody'); pb.textContent = '';
      d.posts.forEach(function (p) {
        pb.appendChild(h('tr', {}, [cell(fmtDate(p.createdAt)), cell(p.title + (p.price > 0 ? '  (' + naira(p.price) + ')' : '') + (p.file ? '  [file: ' + p.file.name + ']' : '')),
          h('td', {}, [btn('Delete', 'danger', function () { if (confirm('Delete this post?')) call('/api/admin/posts/' + p.id, 'DELETE').then(load).catch(fail); })])]));
      });
      var paidOrders = d.orders.filter(function (o) { return o.status === 'paid'; });
      $('#sRev').textContent = naira(paidOrders.reduce(function (t, o) { return t + o.amount; }, 0));
      var ob = $('#ordBody'); ob.textContent = '';
      d.orders.slice().reverse().forEach(function (o) {
        ob.appendChild(h('tr', {}, [cell(fmtDate(o.createdAt)), cell(o.title), cell(o.email), cell(naira(o.amount)), cell(o.status)]));
      });
      if (!d.orders.length) ob.appendChild(h('tr', {}, [h('td', { colspan: 5, text: 'No lesson sales yet.' })]));

      if (!settingsFilled && d.settings) {
        settingsFilled = true; var st = d.settings;
        for (var i = 0; i < 4; i++) { var row = (st.stats || [])[i] || {}; $('#st' + i + 'v').value = row.value || ''; $('#st' + i + 'l').value = row.label || ''; }
        $('#sPhone').value = st.phone || ''; $('#sEmail').value = st.email || ''; $('#sHours').value = st.hours || '';
      }
      var tb = $('#tstBody'); tb.textContent = '';
      (d.testimonials || []).forEach(function (t) {
        tb.appendChild(h('tr', {}, [cell(t.name + (t.role ? ' (' + t.role + ')' : '')), cell(t.quote, 'wrap'),
          h('td', {}, [btn('Delete', 'danger', function () { if (confirm('Delete this testimonial?')) call('/api/admin/testimonials/' + t.id, 'DELETE').then(load).catch(fail); })])]));
      });
      if (!(d.testimonials || []).length) tb.appendChild(h('tr', {}, [h('td', { colspan: 3, text: 'No testimonials yet.' })]));

      var sv = $('#svcBody'); sv.textContent = '';
      d.services.forEach(function (x) {
        var inp = h('input', { type: 'number', min: '0', value: String(x.price) });
        sv.appendChild(h('tr', {}, [cell(x.name), h('td', {}, [inp]),
          h('td', {}, [h('div', { class: 'row-actions' }, [
            btn('Save price', '', function () { call('/api/admin/services/' + x.id, 'PATCH', { price: inp.value }).then(function () { notice(dashMsg, 'ok', 'Price saved.'); load(); }).catch(fail); }),
            btn('Delete', 'danger', function () { if (confirm('Delete this service?')) call('/api/admin/services/' + x.id, 'DELETE').then(load).catch(fail); })])])]));
      });
      var po = $('#porBody'); po.textContent = '';
      d.portfolio.forEach(function (x) {
        var first = h('td', {}, x.image ? [h('img', { class: 'thumb', src: x.image, alt: '', referrerpolicy: 'no-referrer' }), h('span', { text: x.title || '(picture)' })] : [h('span', { text: x.title })]);
        po.appendChild(h('tr', {}, [first, cell(x.category || ''),
          h('td', {}, [btn('Delete', 'danger', function () { if (confirm('Delete this project?')) call('/api/admin/portfolio/' + x.id, 'DELETE').then(load).catch(fail); })])]));
      });
      if (!d.portfolio.length) po.appendChild(h('tr', {}, [h('td', { colspan: 3, text: 'No projects yet. Add your best work above.' })]));

      var sb = $('#subBody'); sb.textContent = '';
      d.subscribers.forEach(function (s) {
        sb.appendChild(h('tr', {}, [cell(s.email), cell(fmtDate(s.createdAt)),
          h('td', {}, [btn('Remove', 'danger', function () { call('/api/admin/subscribers/' + s.id, 'DELETE').then(load).catch(fail); })])]));
      });
      if (!d.subscribers.length) sb.appendChild(h('tr', {}, [h('td', { colspan: 3, text: 'No subscribers yet.' })]));
    } catch (e) { /* handled in call() */ }
  }

  $('#loginForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    try {
      var d = await api('/api/admin/login', { method: 'POST', body: { password: $('#pw').value } });
      csrf = d.csrf; $('#pw').value = ''; showDash();
    } catch (err) { notice($('#loginMsg'), 'err', err.message); }
  });
  $('#logoutBtn').addEventListener('click', function () { call('/api/admin/logout', 'POST').finally(function () { csrf = ''; showLogin(); }); });
  $('#mailBtn').addEventListener('click', function () {
    call('/api/admin/test-email', 'POST').then(function (r) { notice(dashMsg, 'ok', 'Test email sent to ' + r.to + '. Check your inbox (and spam).'); }).catch(fail);
  });
  function uploadFile(f) {
    return fetch('/api/admin/upload-file', { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream', 'X-CSRF-Token': csrf, 'X-File-Name': encodeURIComponent(f.name) }, body: f })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.error || 'Upload failed.'); return d; }); });
  }
  $('#postForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    var btn = $('#postForm').querySelector('button[type=submit]'); btn.disabled = true;
    try {
      var fileId = '', fileName = '', f = $('#pFile').files[0];
      if (f) { notice(dashMsg, 'ok', 'Uploading your file, please wait...'); var up = await uploadFile(f); fileId = up.fileId; fileName = up.name; }
      await call('/api/admin/posts', 'POST', { title: $('#pTitle').value, content: $('#pContent').value, price: $('#pPrice').value, premium: $('#pPremium').value, fileId: fileId, fileName: fileName });
      $('#postForm').reset(); notice(dashMsg, 'ok', 'Published!'); load();
    } catch (err) { fail(err); }
    btn.disabled = false;
  });
  $('#setForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var stats = []; for (var i = 0; i < 4; i++) stats.push({ value: $('#st' + i + 'v').value, label: $('#st' + i + 'l').value });
    call('/api/admin/settings', 'PUT', { stats: stats, phone: $('#sPhone').value, email: $('#sEmail').value, hours: $('#sHours').value })
      .then(function () { notice(dashMsg, 'ok', 'Saved. Refresh your home page to see it.'); }).catch(fail);
  });
  $('#tstForm').addEventListener('submit', function (e) {
    e.preventDefault();
    call('/api/admin/testimonials', 'POST', { quote: $('#tQuote').value, name: $('#tName').value, role: $('#tRole').value })
      .then(function () { $('#tstForm').reset(); notice(dashMsg, 'ok', 'Testimonial added.'); load(); }).catch(fail);
  });
  $('#svcForm').addEventListener('submit', function (e) {
    e.preventDefault();
    call('/api/admin/services', 'POST', { name: $('#sName').value, description: $('#sDesc').value, price: $('#sPrice').value, unit: $('#sUnit').value })
      .then(function () { $('#svcForm').reset(); notice(dashMsg, 'ok', 'Service added.'); load(); }).catch(fail);
  });
  $('#porForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    var btn = $('#porForm').querySelector('button[type=submit]'); btn.disabled = true;
    try {
      var files = [].slice.call($('#oFiles').files), title = $('#oTitle').value;
      var base = { category: $('#oCat').value, description: $('#oDesc').value, link: $('#oLink').value };
      if (files.length) {
        for (var i = 0; i < files.length; i++) {
          notice(dashMsg, 'ok', 'Uploading picture ' + (i + 1) + ' of ' + files.length + '...');
          var up = await uploadBlob(await shrink(files[i], 2000));
          await call('/api/admin/portfolio', 'POST', Object.assign({}, base, { title: files.length === 1 ? title : (title ? title + ' ' + (i + 1) : ''), image: up.src }));
        }
      } else {
        await call('/api/admin/portfolio', 'POST', Object.assign({}, base, { title: title, image: $('#oImgLink').value.trim() }));
      }
      $('#porForm').reset(); notice(dashMsg, 'ok', 'Added to your portfolio.'); load();
    } catch (err) { fail(err); }
    btn.disabled = false;
  });
  api('/api/admin/session').then(function (s) { if (s.authenticated) { csrf = s.csrf; showDash(); } else showLogin(); }).catch(showLogin);
})();
